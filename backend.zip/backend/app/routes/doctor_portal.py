from datetime import date, datetime, time, timezone
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_doctor_profile, require_doctor
from app.database import get_db
from app.models import (
    Appointment,
    Conversation,
    Doctor,
    DoctorNote,
    Message,
    Patient,
    PatientSummary,
    Report,
    SymptomAssessment,
    UrgentConsultOffer,
    UrgentConsultRequest,
    User,
)
from app.services.flow_state import get_flow
from app.services.patient_context import load_patient_context
from app.services.symptom_extraction import resolve_detected_symptoms
from app.models import DoctorAvailability
from app.models.enums import AppointmentStatus
from app.schemas.common import ResponseEnvelope
from app.services.appointment_service import (
    appointment_supports_video_call,
    cancel_appointment_by_doctor,
    format_apt_id,
)
from app.services.doctor_service import create_default_availability, get_availability
from app.schemas.notifications import (
    MarkNotificationsReadRequest,
    MarkNotificationsReadResponse,
    NotificationUnreadCountResponse,
)
from app.services.notification_service import (
    count_unread_notifications,
    list_notifications_for_user,
    mark_notifications_read,
)
from app.services.refill_service import (
    approve_refill_request,
    deny_refill_request,
    list_refills_for_doctor,
)
from app.services.vitals_service import extract_health_vitals_from_reports
from app.services.urgent_consult_service import (
    accept_urgent_request,
    decline_urgent_request,
    list_pending_for_doctor,
    list_urgent_consult_history_for_doctor,
)
from app.services.patient_consult_summary_service import build_patient_consult_overview
from app.services.visit_records_service import (
    list_consultation_history_for_doctor,
    list_visit_records_for_doctor,
)
from app.services.consultation_transcript_service import list_patient_video_transcripts

router = APIRouter(prefix="/doctor", tags=["doctor-portal"])


class AddSlotsRequest(BaseModel):
    slot_date: date
    times: list[str] = Field(min_length=1, description="Times like 09:00, 14:30")


class SOAPNote(BaseModel):
    subjective: str | None = None
    objective: str | None = None
    assessment: str | None = None
    plan: str | None = None
    appointment_id: UUID | None = None


class RefillDenyRequest(BaseModel):
    reason: str | None = None


class AppointmentStatusUpdateRequest(BaseModel):
    reason: str | None = None


async def _verify_access(db: AsyncSession, doctor_id: UUID, patient_id: UUID) -> bool:
    result = await db.execute(
        select(Appointment).where(
            Appointment.doctor_id == doctor_id,
            Appointment.patient_id == patient_id,
            Appointment.status.in_([AppointmentStatus.confirmed, AppointmentStatus.completed, AppointmentStatus.pending]),
        ).limit(1)
    )
    if result.scalar_one_or_none() is not None:
        return True
    urgent = await db.execute(
        select(UrgentConsultOffer.id)
        .join(UrgentConsultRequest, UrgentConsultOffer.request_id == UrgentConsultRequest.id)
        .where(
            UrgentConsultOffer.doctor_id == doctor_id,
            UrgentConsultRequest.patient_id == patient_id,
        )
        .limit(1)
    )
    return urgent.scalar_one_or_none() is not None


def _format_appt_row(
    a: Appointment,
    patient_id: UUID,
    patient_name: str,
    *,
    linked_report: dict | None = None,
) -> dict:
    status = a.status.value if hasattr(a.status, "value") else str(a.status)
    row = {
        "appointment_id": str(a.id),
        "apt_id": format_apt_id(a.id),
        "patient_id": str(patient_id),
        "patient_name": patient_name,
        "date": str(a.slot_date),
        "time": str(a.slot_time),
        "status": status,
        "consultation_mode": a.consultation_mode or "in_person",
        "is_video": appointment_supports_video_call(a),
        "appointment_reason": a.appointment_reason,
        "linked_report_id": str(a.linked_report_id) if a.linked_report_id else None,
    }
    if linked_report:
        row["linked_report"] = linked_report
    return row


def _linked_report_payload(report: Report | None) -> dict | None:
    if not report:
        return None
    meta = (report.analysis_json or {}).get("_meta") or {}
    analysis = report.analysis_json or {}
    return {
        "report_id": str(report.id),
        "filename": meta.get("filename") or "Medical report",
        "summary": (analysis.get("summary") or "").strip(),
        "abnormal": analysis.get("abnormal") or [],
        "created_at": report.created_at.isoformat() if report.created_at else None,
    }


@router.get("/appointments")
async def all_appointments(doctor: Doctor = Depends(get_doctor_profile), db: AsyncSession = Depends(get_db)):
    """All appointments for the logged-in doctor."""
    result = await db.execute(
        select(Appointment, Patient, User)
        .join(Patient, Appointment.patient_id == Patient.id)
        .join(User, Patient.user_id == User.id)
        .where(Appointment.doctor_id == doctor.id)
        .order_by(Appointment.slot_date.desc(), Appointment.slot_time.desc())
    )
    rows = result.all()
    report_ids = {a.linked_report_id for a, _, _ in rows if a.linked_report_id}
    reports_by_id: dict[UUID, Report] = {}
    if report_ids:
        report_rows = await db.execute(select(Report).where(Report.id.in_(report_ids)))
        reports_by_id = {r.id: r for r in report_rows.scalars().all()}

    return ResponseEnvelope(
        data=[
            _format_appt_row(
                a,
                p.id,
                u.name,
                linked_report=_linked_report_payload(reports_by_id.get(a.linked_report_id))
                if a.linked_report_id
                else None,
            )
            for a, p, u in rows
        ]
    )


@router.get("/availability")
async def my_availability(doctor: Doctor = Depends(get_doctor_profile), db: AsyncSession = Depends(get_db)):
    return ResponseEnvelope(data=await get_availability(db, doctor.id))


@router.post("/availability")
async def add_availability(
    data: AddSlotsRequest,
    doctor: Doctor = Depends(get_doctor_profile),
    db: AsyncSession = Depends(get_db),
):
    added = 0
    for t_str in data.times:
        parts = t_str.strip().split(":")
        hour, minute = int(parts[0]), int(parts[1]) if len(parts) > 1 else 0
        slot_time = time(hour, minute)
        exists = await db.execute(
            select(DoctorAvailability).where(
                DoctorAvailability.doctor_id == doctor.id,
                DoctorAvailability.slot_date == data.slot_date,
                DoctorAvailability.slot_time == slot_time,
            )
        )
        if not exists.scalar_one_or_none():
            db.add(DoctorAvailability(
                doctor_id=doctor.id, slot_date=data.slot_date, slot_time=slot_time, status="available"
            ))
            added += 1
    await db.flush()
    return ResponseEnvelope(data={"added": added})


@router.post("/availability/seed-default")
async def seed_my_availability(doctor: Doctor = Depends(get_doctor_profile), db: AsyncSession = Depends(get_db)):
    """Generate 14 days of default slots if doctor has none."""
    added = await create_default_availability(db, doctor.id)
    return ResponseEnvelope(data={"added": added})


@router.get("/appointments/today")
async def today_appointments(doctor: Doctor = Depends(get_doctor_profile), db: AsyncSession = Depends(get_db)):
    today = date.today()
    result = await db.execute(
        select(Appointment, Patient, User)
        .join(Patient, Appointment.patient_id == Patient.id)
        .join(User, Patient.user_id == User.id)
        .where(Appointment.doctor_id == doctor.id, Appointment.slot_date == today)
        .order_by(Appointment.slot_time)
    )
    return ResponseEnvelope(
        data=[_format_appt_row(a, p.id, u.name) for a, p, u in result.all()]
    )


@router.get("/patients")
async def my_patients(doctor: Doctor = Depends(get_doctor_profile), db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Patient, User)
        .join(User, Patient.user_id == User.id)
        .join(Appointment, Appointment.patient_id == Patient.id)
        .where(Appointment.doctor_id == doctor.id)
        .distinct()
    )
    return ResponseEnvelope(data=[{"patient_id": str(p.id), "name": u.name} for p, u in result.all()])


@router.get("/patients/{patient_id}")
async def patient_detail(
    patient_id: UUID, doctor: Doctor = Depends(get_doctor_profile), db: AsyncSession = Depends(get_db)
):
    if not await _verify_access(db, doctor.id, patient_id):
        raise HTTPException(status_code=403, detail="Forbidden")

    patient = await db.get(Patient, patient_id)
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")
    user = await db.get(User, patient.user_id)

    appt_rows = await db.execute(
        select(Appointment)
        .where(Appointment.doctor_id == doctor.id, Appointment.patient_id == patient_id)
        .order_by(Appointment.slot_date.desc(), Appointment.slot_time.desc())
    )
    appt_list = list(appt_rows.scalars().all())
    report_ids = {a.linked_report_id for a in appt_list if a.linked_report_id}
    reports_by_id: dict[UUID, Report] = {}
    if report_ids:
        report_rows = await db.execute(select(Report).where(Report.id.in_(report_ids)))
        reports_by_id = {r.id: r for r in report_rows.scalars().all()}

    appointments = [
        {
            "appointment_id": str(a.id),
            "apt_id": format_apt_id(a.id),
            "date": str(a.slot_date),
            "time": str(a.slot_time),
            "status": a.status.value if hasattr(a.status, "value") else str(a.status),
            "completed_at": a.completed_at.isoformat() if a.completed_at else None,
            "consultation_mode": a.consultation_mode or "in_person",
            "is_video": appointment_supports_video_call(a),
            "appointment_reason": a.appointment_reason,
            "linked_report_id": str(a.linked_report_id) if a.linked_report_id else None,
            "linked_report": _linked_report_payload(reports_by_id.get(a.linked_report_id))
            if a.linked_report_id
            else None,
        }
        for a in appt_list
    ]

    summary_row = await db.execute(
        select(PatientSummary)
        .where(PatientSummary.patient_id == patient_id)
        .order_by(PatientSummary.generated_at.desc())
        .limit(1)
    )
    summary = summary_row.scalar_one_or_none()

    return ResponseEnvelope(
        data={
            "patient_id": str(patient_id),
            "name": user.name if user else "Patient",
            "email": user.email if user else "",
            "phone": patient.phone,
            "dob": str(patient.dob) if patient.dob else None,
            "gender": patient.gender,
            "blood_group": patient.blood_group,
            "appointments": appointments,
            "summary": summary.summary_text if summary else "No AI summary yet. Summary is generated when patient books via chatbot.",
        }
    )


@router.get("/patients/{patient_id}/summary")
async def patient_summary(
    patient_id: UUID, doctor: Doctor = Depends(get_doctor_profile), db: AsyncSession = Depends(get_db)
):
    if not await _verify_access(db, doctor.id, patient_id):
        raise HTTPException(status_code=403, detail="Forbidden")
    result = await db.execute(
        select(PatientSummary)
        .where(PatientSummary.patient_id == patient_id)
        .order_by(PatientSummary.generated_at.desc())
        .limit(1)
    )
    summary = result.scalar_one_or_none()
    return ResponseEnvelope(data={"summary": summary.summary_text if summary else "No summary yet"})


@router.get("/consultation-history")
async def doctor_consultation_history(
    doctor: Doctor = Depends(get_doctor_profile),
    db: AsyncSession = Depends(get_db),
):
    """All patient visits for this doctor with symptoms, medications, and consult notes."""
    data = await list_consultation_history_for_doctor(db, doctor.id)
    return ResponseEnvelope(data=data)


@router.get("/patients/{patient_id}/visit-records")
async def patient_visit_records(
    patient_id: UUID, doctor: Doctor = Depends(get_doctor_profile), db: AsyncSession = Depends(get_db)
):
    if not await _verify_access(db, doctor.id, patient_id):
        raise HTTPException(status_code=403, detail="Forbidden")
    data = await list_visit_records_for_doctor(db, doctor.id, patient_id)
    return ResponseEnvelope(data=data)


@router.get("/patients/{patient_id}/video-transcripts")
async def patient_video_transcripts(
    patient_id: UUID, doctor: Doctor = Depends(get_doctor_profile), db: AsyncSession = Depends(get_db)
):
    if not await _verify_access(db, doctor.id, patient_id):
        raise HTTPException(status_code=403, detail="Forbidden")
    items = await list_patient_video_transcripts(db, doctor.id, patient_id)
    return ResponseEnvelope(data={"items": items})


@router.get("/patients/{patient_id}/consultation-summary")
async def patient_consultation_summary(
    patient_id: UUID, doctor: Doctor = Depends(get_doctor_profile), db: AsyncSession = Depends(get_db)
):
    if not await _verify_access(db, doctor.id, patient_id):
        raise HTTPException(status_code=403, detail="Forbidden")

    patient = await db.get(Patient, patient_id)
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    ctx = await load_patient_context(db, patient)

    assessment_rows = await db.execute(
        select(SymptomAssessment)
        .where(SymptomAssessment.patient_id == patient_id)
        .order_by(SymptomAssessment.completed_at.desc())
        .limit(10)
    )
    from app.services.symptom_service import assessment_payload_from_row

    assessments = [assessment_payload_from_row(a) for a in assessment_rows.scalars().all()]

    conv_rows = await db.execute(
        select(Conversation)
        .where(Conversation.patient_id == patient_id)
        .order_by(Conversation.created_at.desc())
    )
    conversations = conv_rows.scalars().all()

    detected_symptoms: list[str] = []
    seen_symptoms: set[str] = set()
    consultation_history = []
    emergency_flag = False
    total_messages = 0

    for conv in conversations:
        emergency_flag = emergency_flag or bool(conv.emergency_flag)
        msg_rows = await db.execute(
            select(Message)
            .where(Message.conversation_id == conv.id)
            .order_by(Message.created_at, Message.id)
        )
        msgs = msg_rows.scalars().all()
        total_messages += len(msgs)
        history = [
            {
                "role": m.role.value if hasattr(m.role, "value") else str(m.role),
                "content": m.content,
            }
            for m in msgs
        ]
        flow = await get_flow(conv.id)
        session = flow.get("session") or {}
        conv_symptoms = await resolve_detected_symptoms(session, history)
        for s in conv_symptoms:
            key = s.strip().lower()
            if key and key not in seen_symptoms:
                seen_symptoms.add(key)
                detected_symptoms.append(s.strip())

        preview = ""
        for m in msgs:
            role = m.role.value if hasattr(m.role, "value") else str(m.role)
            if role == "user" and m.content:
                preview = m.content.strip()[:160]
                break
        if not preview and msgs:
            preview = (msgs[-1].content or "").strip()[:160]

        consultation_history.append({
            "conversation_id": str(conv.id),
            "title": conv.title or "Health Chat",
            "created_at": conv.created_at.isoformat() if conv.created_at else None,
            "message_count": len(msgs),
            "emergency_flag": conv.emergency_flag,
            "detected_symptoms": conv_symptoms,
            "preview": preview,
        })

    latest = assessments[0] if assessments else None
    patient_consult_overview = await build_patient_consult_overview(db, doctor.id, patient_id)
    return ResponseEnvelope(
        data={
            "detected_symptoms": detected_symptoms,
            "risk_level": latest.get("risk_level") if latest else None,
            "recommended_specialty": latest.get("recommended_specialty") if latest else None,
            "recommendation_text": latest.get("recommendation_text") if latest else None,
            "duration": latest.get("duration") if latest else None,
            "emergency_flag": emergency_flag,
            "conversation_count": len(conversations),
            "total_messages": total_messages,
            "assessments": assessments,
            "consultation_history": consultation_history,
            "conditions": ctx.get("conditions") or [],
            "medications": ctx.get("medications") or [],
            "allergies": ctx.get("allergies") or [],
            "memory_facts": ctx.get("memory_facts") or [],
            "patient_consult_overview": patient_consult_overview,
        }
    )


@router.get("/patients/{patient_id}/conversations")
async def patient_conversations(
    patient_id: UUID, doctor: Doctor = Depends(get_doctor_profile), db: AsyncSession = Depends(get_db)
):
    if not await _verify_access(db, doctor.id, patient_id):
        raise HTTPException(status_code=403)
    convs = await db.execute(
        select(Conversation)
        .where(Conversation.patient_id == patient_id)
        .order_by(Conversation.created_at.desc())
    )
    data = []
    for c in convs.scalars().all():
        msgs = await db.execute(
            select(Message)
            .where(Message.conversation_id == c.id)
            .order_by(Message.created_at)
        )
        data.append({
            "conversation_id": str(c.id),
            "title": c.title or "Health Chat",
            "created_at": c.created_at.isoformat() if c.created_at else None,
            "emergency_flag": c.emergency_flag,
            "messages": [
                {
                    "role": m.role.value if hasattr(m.role, "value") else str(m.role),
                    "content": m.content,
                    "created_at": m.created_at.isoformat() if m.created_at else None,
                }
                for m in msgs.scalars().all()
            ],
        })
    return ResponseEnvelope(data=data)


@router.get("/patients/{patient_id}/reports")
async def patient_reports(
    patient_id: UUID, doctor: Doctor = Depends(get_doctor_profile), db: AsyncSession = Depends(get_db)
):
    if not await _verify_access(db, doctor.id, patient_id):
        raise HTTPException(status_code=403)
    result = await db.execute(
        select(Report).where(Report.patient_id == patient_id).order_by(Report.created_at.desc())
    )
    return ResponseEnvelope(
        data=[
            {
                "id": str(r.id),
                "analysis": r.analysis_json,
                "created_at": r.created_at.isoformat() if r.created_at else None,
            }
            for r in result.scalars().all()
        ]
    )


@router.get("/patients/{patient_id}/health-vitals")
async def patient_health_vitals(
    patient_id: UUID, doctor: Doctor = Depends(get_doctor_profile), db: AsyncSession = Depends(get_db)
):
    if not await _verify_access(db, doctor.id, patient_id):
        raise HTTPException(status_code=403)
    result = await db.execute(
        select(Report).where(Report.patient_id == patient_id).order_by(Report.created_at.desc())
    )
    reports = list(result.scalars().all())
    vitals = extract_health_vitals_from_reports(reports)
    return ResponseEnvelope(data={"vitals": vitals, "has_data": len(vitals) > 0})


@router.post("/patients/{patient_id}/soap-notes")
async def create_soap(
    patient_id: UUID,
    data: SOAPNote,
    doctor: Doctor = Depends(get_doctor_profile),
    db: AsyncSession = Depends(get_db),
):
    if not await _verify_access(db, doctor.id, patient_id):
        raise HTTPException(status_code=403)
    note = DoctorNote(doctor_id=doctor.id, patient_id=patient_id, **data.model_dump())
    db.add(note)
    await db.flush()
    return ResponseEnvelope(data={"id": str(note.id)})


@router.post("/appointments/{appointment_id}/complete")
async def complete_appointment(
    appointment_id: UUID, doctor: Doctor = Depends(get_doctor_profile), db: AsyncSession = Depends(get_db)
):
    appt = await db.get(Appointment, appointment_id)
    if not appt or appt.doctor_id != doctor.id:
        raise HTTPException(status_code=404, detail="Appointment not found")
    appt.status = AppointmentStatus.completed
    # DB column is TIMESTAMP WITHOUT TIME ZONE — store naive UTC
    appt.completed_at = datetime.now(timezone.utc).replace(tzinfo=None)
    await db.flush()
    from app.services.appointment_card_service import sync_appointment_status_on_patient_cards

    await sync_appointment_status_on_patient_cards(db, appointment_id)
    return ResponseEnvelope(
        data={
            "status": "completed",
            "appointment_id": str(appointment_id),
            "apt_id": format_apt_id(appt.id),
        }
    )


@router.post("/appointments/{appointment_id}/cancel")
async def cancel_appointment_doctor(
    appointment_id: UUID,
    data: AppointmentStatusUpdateRequest,
    doctor: Doctor = Depends(get_doctor_profile),
    db: AsyncSession = Depends(get_db),
):
    appt = await cancel_appointment_by_doctor(db, appointment_id, doctor.id, data.reason)
    from app.services.appointment_card_service import sync_appointment_status_on_patient_cards

    await sync_appointment_status_on_patient_cards(db, appointment_id)
    return ResponseEnvelope(
        data={
            "status": "cancelled",
            "appointment_id": str(appointment_id),
            "apt_id": format_apt_id(appt.id),
        }
    )


@router.get("/refill-requests")
async def doctor_refill_requests(
    status: str | None = None,
    doctor: Doctor = Depends(get_doctor_profile),
    db: AsyncSession = Depends(get_db),
):
    data = await list_refills_for_doctor(db, doctor.id, status=status)
    return ResponseEnvelope(data=data)


@router.post("/refill-requests/{request_id}/approve")
async def doctor_approve_refill(
    request_id: UUID,
    doctor: Doctor = Depends(get_doctor_profile),
    db: AsyncSession = Depends(get_db),
):
    result = await approve_refill_request(db, doctor.id, request_id)
    return ResponseEnvelope(data=result)


@router.post("/refill-requests/{request_id}/deny")
async def doctor_deny_refill(
    request_id: UUID,
    data: RefillDenyRequest,
    doctor: Doctor = Depends(get_doctor_profile),
    db: AsyncSession = Depends(get_db),
):
    result = await deny_refill_request(db, doctor.id, request_id, data.reason)
    return ResponseEnvelope(data=result)


@router.get("/notifications")
async def doctor_notifications(
    doctor: Doctor = Depends(get_doctor_profile),
    db: AsyncSession = Depends(get_db),
):
    data = await list_notifications_for_user(db, doctor.user_id)
    return ResponseEnvelope(data=data)


@router.get("/notifications/unread-count", response_model=ResponseEnvelope[NotificationUnreadCountResponse])
async def doctor_notifications_unread_count(
    doctor: Doctor = Depends(get_doctor_profile),
    db: AsyncSession = Depends(get_db),
):
    count = await count_unread_notifications(db, doctor.user_id)
    return ResponseEnvelope(data=NotificationUnreadCountResponse(count=count))


@router.post("/notifications/mark-read", response_model=ResponseEnvelope[MarkNotificationsReadResponse])
async def doctor_notifications_mark_read(
    data: MarkNotificationsReadRequest,
    doctor: Doctor = Depends(get_doctor_profile),
    db: AsyncSession = Depends(get_db),
):
    marked = await mark_notifications_read(db, doctor.user_id, data.ids)
    return ResponseEnvelope(data=MarkNotificationsReadResponse(marked=marked))


@router.get("/urgent-consult/pending")
async def doctor_urgent_consult_pending(
    doctor: Doctor = Depends(get_doctor_profile),
    db: AsyncSession = Depends(get_db),
):
    data = await list_pending_for_doctor(db, doctor.id)
    return ResponseEnvelope(data=data)


@router.get("/urgent-consult/history")
async def doctor_urgent_consult_history(
    bucket: str | None = None,
    doctor: Doctor = Depends(get_doctor_profile),
    db: AsyncSession = Depends(get_db),
):
    """Audit list — attended, declined, or missed urgent consults with patient details."""
    data = await list_urgent_consult_history_for_doctor(db, doctor.id, bucket=bucket)
    return ResponseEnvelope(data=data)


@router.post("/urgent-consult/{request_id}/accept")
async def doctor_accept_urgent_consult(
    request_id: UUID,
    doctor: Doctor = Depends(get_doctor_profile),
    db: AsyncSession = Depends(get_db),
):
    user = await db.get(User, doctor.user_id)
    doctor_name = user.name if user else "Doctor"
    payload = await accept_urgent_request(
        db,
        doctor.id,
        request_id,
        doctor_user_id=doctor.user_id,
        doctor_name=doctor_name,
    )
    await db.commit()
    return ResponseEnvelope(data=payload)


@router.post("/urgent-consult/{request_id}/decline")
async def doctor_decline_urgent_consult(
    request_id: UUID,
    doctor: Doctor = Depends(get_doctor_profile),
    db: AsyncSession = Depends(get_db),
):
    payload = await decline_urgent_request(db, doctor.id, request_id)
    await db.commit()
    return ResponseEnvelope(data=payload)
